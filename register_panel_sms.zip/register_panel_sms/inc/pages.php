<?php
function panel_sms_setting_page(){
	global $wpdb, $table_prefix;
    
	if(isset($_POST['submit'])){
		update_option( 'select_panel_rps', $_POST['select_panel_rps'] );
		update_option( 'user_rps', $_POST['user_rps'] );
		update_option( 'user_pass_rps', $_POST['user_pass_rps'] );
		update_option( 'num_rps', $_POST['num_rps'] );
		update_option( 'cell_mobile_admin', $_POST['cell_mobile_admin'] );
		update_option( 'Success_user_page', $_POST['Success_user_page'] );
		
		
		update_option( 'User_failed_page', $_POST['User_failed_page'] );
		update_option( 'pattern_user_success', $_POST['pattern_user_success'] );
		update_option( 'pattern_user_failed', $_POST['pattern_user_failed'] );
		update_option( 'pattern_admin_success', $_POST['pattern_admin_success'] );
		update_option( 'pattern_admin_failed', $_POST['pattern_admin_failed'] );
		update_option( 'voice_tanks_user', $_POST['voice_tanks_user'] );
		
		update_option( 'user_name_varible', $_POST['user_name_varible'] );
		update_option( 'user_name_code_meli', $_POST['user_name_code_meli'] );
		update_option( 'first_user_name', $_POST['first_user_name'] );
		
		update_option( 'password_varible', $_POST['password_varible'] );
		update_option( 'password_code_meli', $_POST['password_code_meli'] );
		update_option( 'first_password', $_POST['first_password'] );
		
		update_option( 'first_lastname_user', $_POST['first_lastname_user'] );
		
		
		update_option( 'codemeli_varible', $_POST['codemeli_varible'] );
		
		update_option( 'shenasnameh_varible', $_POST['shenasnameh_varible'] );
		
		if($_POST['shenasnameh_varible'] == 'fix'){
		   update_option( 'shenasnameh_fix_name', $_POST['codemeli_fix_name'] ); 
		}
		
		update_option( 'cell_phone_varible', $_POST['cell_phone_varible'] );
		
		update_option( 'phone_varible', $_POST['phone_varible'] );
	
		update_option( 'code_posti_varible', $_POST['code_posti_varible'] );
		
		update_option( 'email_user', $_POST['email_user'] );
		update_option( 'address_user', $_POST['address_user'] );
		update_option( 'Banking_gateway', $_POST['Banking_gateway'] );
		update_option( 'api_key_gateway', $_POST['api_key_gateway'] );
		update_option( 'sandbox_gateway', $_POST['sandbox_gateway'] );
		
		update_option( 'company_varible_name', $_POST['company_varible_name'] );
		update_option( 'company_fix_name', $_POST['company_fix_name'] );
		update_option( 'codemeli_fix_name', $_POST['codemeli_fix_name'] );
		
		update_option( 'cell_phone_fix_name', $_POST['cell_phone_fix_name'] );
		update_option( 'phone_fix_name', $_POST['phone_fix_name'] );
		update_option( 'code_posti_fix_name', $_POST['code_posti_fix_name'] );
		update_option( 'email_fix_name', $_POST['email_fix_name'] );
		update_option( 'address_fix_name', $_POST['address_fix_name'] );
		
		update_option( 'show_text_pakage', $_POST['show_text_pakage'] );
		update_option( 'text_register_user', $_POST['text_register_user'] );
		//$transaction_id = woo_wallet()->wallet->credit(1, 200, __('Commission received for commission id #', 'woo-wallet') );
		//var_dump($transaction_id);
		
		$count_ = $_POST['count_record'];
		$wpdb->query("DELETE FROM {$table_prefix}package_list_sms");
        for($i=1;$i<intval($count_);$i++){
		  $Package_id     = $_POST['Package_id_'.$i];
		  $Package_name   = $_POST['Package_name_'.$i];
		  $Package_price  = $_POST['Package_price_'.$i];
		  $Package_status = $_POST['Package_status_'.$i];
		  
		  if($Package_name!='' && $Package_price!=''){
		    $sql="INSERT INTO {$table_prefix}package_list_sms (Package_id,Package_name,Package_price,Package_status) ";
            $sql.="VALUES('{$Package_id}','{$Package_name}','{$Package_price}','{$Package_status}')";
            $res=$wpdb->query($sql);
		  }
		}
	}
	
	$select_panel_rps      = get_option('select_panel_rps');
	$Success_user_page     = get_option('Success_user_page');
	?>
	<style>		
	.tabs h2 {
		margin-top: 0;
	}

	.tabs p {
		display: block;
		margin: 0;
	}

	hr {
		border: 0;
		border-bottom: 1px solid #ccc;
		margin: 30px 0;
		height: 0;
	}
	@media screen and (max-width: 600px) {
		.mobile_call {
          width: 62% !important;
        }
	}
	</style>
	<link rel="stylesheet" type="text/css" href="<?php echo register_panel_CSS_URL ?>/vanilla-tabs.min.css">
	
	<form action="" method="post">
	  <p>
	     <div style="float: right;width: 30%;">
	       <img src="<?php echo register_panel_IMG_URL ?>logo_register.png" style="height: 91px !important;width: 94% !important;"> 
	     </div>
	     <div style="float: left;width: 65%;">
            <h3 style="font-family: iranyekan;text-align: center;color: #717b86;">تنظیمات پلاگین ثبت نام کاربر</h3>
	        <h4 style="font-family: iranyekan;text-align: center;color: #717b86;">
              شورت کد ثبت نام کاربر : [create_user_sms]
	        </h4>
	     </div>
	  </p>
	  
	  
	  <ul id="tabs-v" class="tabs" style="width: 97% !important;">
	   <li data-title="ورود اطلاعات">
		  <p>
            <label for="select_panel_rps">سامانه پیامکی
              <br/>
              <select class="mobile_call" name="select_panel_rps" id="select_panel_rps" style="width: 199px;">
                <option value="yek_payamak" <?php if($select_panel_rps=='yek_payamak'){ echo 'selected'; } ?>>یک پیامک</option>
                <option value="IPPANEL" <?php if($select_panel_rps=='IPPANEL'){ echo 'selected'; } ?>>IPPANEL</option>
              </select>
            </label><br/><br/>
            
            <label for="user_rps">نام کاربری
              <br/><input type="text" class="mobile_call" style="width: 199px;" name="user_rps" value="<?php echo get_option('user_rps'); ?>">
            </label><br/><br/>
           
            <label for="user_pass_rps">رمز عبور
              <br/><input type="text" class="mobile_call" style="width: 199px;" name="user_pass_rps" value="<?php echo get_option('user_pass_rps'); ?>">
            </label><br/><br/>
			
		    <label for="num_rps">شماره ارسال کننده
              <br/><input type="text" class="mobile_call"  name="num_rps" style="width: 199px;" value="<?php echo get_option('num_rps'); ?>">
            </label><br/><br/>
		
   		    <label for="cell_mobile_admin">شماره همراه ادمین
              <br/><input type="text" class="mobile_call" style="width: 199px;" name="cell_mobile_admin" value="<?php echo get_option('cell_mobile_admin'); ?>">
            </label><br/><br/>
			
			<label for="Success_user_page">صفحه موفق بودن ساخت کاربر
              <br/>
              <select  class="mobile_call" name="Success_user_page" id="Success_user_page" style="width: 199px;">
                <option value="-1" <?php if($Success_user_page=='-1'){ echo 'selected'; } ?>>انتخاب کنید</option>
                <?php 
                $pages = get_pages(); 
                foreach ( $pages as $page ) {
                  $selected ='';
                  if($Success_user_page==get_page_link( $page->ID )){ $selected = 'selected'; }
                  $option = '<option value="' . get_page_link( $page->ID ) . '" '.$selected.'>';
                  $option .= $page->post_title;
                  $option .= '</option>';
                  echo $option;
                }
                ?>
              </select>
            </label><br/><br/>
			
			<label for="User_failed_page">صفحه نا موفق بودن ساخت کاربر
              <br/>
              <?php 
              $User_failed_page = get_option('User_failed_page');
              ?>
              <select class="mobile_call"  name="User_failed_page" id="User_failed_page" style="width: 199px;">
                <option value="-1" <?php if($User_failed_page=='-1'){ echo 'selected'; } ?>>انتخاب کنید</option>
                <?php 
                $pages = get_pages(); 
                foreach ( $pages as $page ) {
                  $selected ='';
                  if($User_failed_page==get_page_link( $page->ID )){ $selected = 'selected'; }
                  $option = '<option value="' . get_page_link( $page->ID ) . '" '.$selected.'>';
                  $option .= $page->post_title;
                  $option .= '</option>';
                  echo $option;
                }
                ?>
              </select>
            </label><br/><br/>
			          
            <label for="pattern_user_success">پترن پیامک ثبت نام موفق برای کاربر
              <br/><input class="mobile_call" type="text" style="width: 199px;" name="pattern_user_success" value="<?php echo get_option('pattern_user_success'); ?>">
            </label><br/><br/>
          
            <label for="pattern_user_failed">پترن پیامک ثبت نام ناموفق برای کاربر
              <br/><input  class="mobile_call" type="text" style="width: 199px;" name="pattern_user_failed" value="<?php echo get_option('pattern_user_failed'); ?>">
            </label><br/><br/>
			
			<label for="pattern_admin_success">پترن پیامک ثبت نام موفق برای مدیر
              <br/><input  class="mobile_call" type="text" style="width: 199px;" name="pattern_admin_success" value="<?php echo get_option('pattern_admin_success'); ?>">
            </label><br/><br/>
          
            <label for="pattern_admin_failed">پترن پیامک ثبت نام ناموفق برای مدیر
              <br/><input  class="mobile_call" type="text" style="width: 199px;" name="pattern_admin_failed" value="<?php echo get_option('pattern_admin_failed'); ?>">
            </label><br/><br/>
			
			<label for="text_register_user">متن دکمه ثبت نام کاربر
              <br/><input  class="mobile_call" type="text" style="width: 199px;" name="text_register_user" value="<?php echo get_option('text_register_user'); ?>">
            </label><br/><br/>
            
			<label for="voice_tanks_user">لینک فایل صوتی
              <br/><input  class="mobile_call" type="text" style="width: 199px;" name="voice_tanks_user" value="<?php echo get_option('voice_tanks_user'); ?>">
            </label><br/><br/>
		  </p>	
	   </li>
	   <li data-title="سفارش سازی فرم">
	      <p>
		    <label for="user_name_register">نام کاربری کاربر              
              <br/>
              <?php 
              $user_name_varible = get_option('user_name_varible');
              ?>
			  <select  class="mobile_call" name="user_name_varible" id="user_name_varible" style="width: 199px;">
                <option value="varible" <?php if($user_name_varible=='varible'){ echo 'selected'; } ?>>متغییر</option>
                <option value="fix" <?php if($user_name_varible=='fix'){ echo 'selected'; } ?>>ثابت</option>
              </select>
			  <?php 
              $user_name_code_meli = get_option('user_name_code_meli');
              ?>
			  <select  class="mobile_call" name="user_name_code_meli" id="user_name_code_meli" style="width: 199px;">
                <option value="code_meli" <?php if($user_name_code_meli=='code_meli'){ echo 'selected'; } ?>>کد ملی</option>
                <option value="cell_phone" <?php if($user_name_code_meli=='cell_phone'){ echo 'selected'; } ?>>شماره موبایل</option>
              </select>
              
              <input  class="mobile_call" style="width: 199px;" type="text" name="first_user_name" placeholder="ابتدای نام کاربری" value="<?php echo get_option('first_user_name'); ?>">
			  
            </label><br/><br/>
			
			<label for="password_register">رمز عبور کاربر              
              <br/>
              <?php 
              $password_varible = get_option('password_varible');
              ?>
              <select class="mobile_call"  name="password_varible" id="password_varible" style="width: 199px;">
                <option value="varible" <?php if($password_varible=='varible'){ echo 'selected'; } ?>>متغییر</option>
              </select>
			  
			  <?php 
              $password_code_meli = get_option('password_code_meli');
              ?>
			  <select class="mobile_call"  name="password_code_meli" id="password_code_meli" style="width: 199px;">
                <option value="code_meli" <?php if($password_code_meli=='code_meli'){ echo 'selected'; } ?>>کد ملی</option>
                <option value="cell_phone" <?php if($password_code_meli=='cell_phone'){ echo 'selected'; } ?>>شماره موبایل</option>
              </select>
              
              <input  class="mobile_call" type="text" name="first_password" placeholder="ابتدای رمز عبور کاربر" value="<?php echo get_option('first_password'); ?>">
			  
            </label><br/><br/>
			
			<label for="first_lastname_user">نام و نام خانوادگی
              <br/><input type="text" name="first_lastname_user" style="width: 199px;" value="<?php echo get_option('first_lastname_user'); ?>">
            </label><br/><br/>
			
			<label for="company_name_user">نام شرکت              
              <br/>
              <?php 
              $company_varible_name = get_option('company_varible_name');
              ?>
              <select  class="mobile_call" name="company_varible_name" id="company_varible_name" style="width: 199px;">
                <option value="varible" <?php if($company_varible_name=='varible'){ echo 'selected'; } ?>>متغییر</option>
                <option value="fix" <?php if($company_varible_name=='fix'){ echo 'selected'; } ?>>ثابت</option>
              </select>
			  
			  <input type="text" name="company_fix_name" style="width: 199px;" id="company_fix_name" value="<?php echo get_option('company_fix_name'); ?>">
            </label><br/><br/>
			
			<label for="codemeli_varible">کد ملی              
              <br/>
              <?php 
              $codemeli_varible = get_option('codemeli_varible');
              ?>
              <select name="codemeli_varible" id="codemeli_varible" style="width: 199px;">
                <option value="varible" <?php if($codemeli_varible=='varible'){ echo 'selected'; } ?>>متغییر</option>
                <option value="fix" <?php if($codemeli_varible=='fix'){ echo 'selected'; } ?>>ثابت</option>
              </select>
              
              <input type="text" name="codemeli_fix_name" style="width: 199px;" id="codemeli_fix_name" value="<?php echo get_option('codemeli_fix_name'); ?>">
            </label><br/><br/>
			
			<label for="shenasnameh_varible">شماره شناسنامه              
              <br/>
              <?php 
              $shenasnameh_varible = get_option('shenasnameh_varible');
              ?>
              <select  class="mobile_call" name="shenasnameh_varible" id="shenasnameh_varible" style="width: 199px;">
                <option value="varible" <?php if($shenasnameh_varible=='varible'){ echo 'selected'; } ?>>متغییر</option>
                <option value="fix" <?php if($shenasnameh_varible=='fix'){ echo 'selected'; } ?>>ثابت</option>
              </select>
			  
			  <input type="text" name="shenasnameh_fix_name" style="width: 199px;" id="shenasnameh_fix_name" value="<?php echo get_option('shenasnameh_fix_name'); ?>">
            </label><br/><br/>
			
			<label for="cell_phone_varible">موبایل              
              <br/>
              <?php 
              $cell_phone_varible = get_option('cell_phone_varible');
              ?>
              <select class="mobile_call"  name="cell_phone_varible" id="cell_phone_varible" style="width: 199px;">
                <option value="varible" <?php if($cell_phone_varible=='varible'){ echo 'selected'; } ?>>متغییر</option>
                <option value="fix" <?php if($cell_phone_varible=='fix'){ echo 'selected'; } ?>>ثابت</option>
              </select>
              
              <input type="text" name="cell_phone_fix_name" id="cell_phone_fix_name" value="<?php echo get_option('cell_phone_fix_name'); ?>">
            </label><br/><br/>
			
			<label for="phone_varible">تلفن ثابت             
              <br/>
              <?php 
              $phone_varible = get_option('phone_varible');
              ?>
              <select class="mobile_call"  name="phone_varible" id="phone_varible" style="width: 199px;">
                <option value="varible" <?php if($phone_varible=='varible'){ echo 'selected'; } ?>>متغییر</option>
                <option value="fix" <?php if($phone_varible=='fix'){ echo 'selected'; } ?>>ثابت</option>
              </select>
			  
			  <input type="text" name="phone_fix_name" style="width: 199px;" id="phone_fix_name" value="<?php echo get_option('phone_fix_name'); ?>">
            </label><br/><br/>
			
			<label for="code_posti_varible">کد پستی              
              <br/>
              <?php 
              $code_posti_varible = get_option('code_posti_varible');
              ?>
              <select class="mobile_call"  name="code_posti_varible" id="code_posti_varible" style="width: 199px;">
                <option value="varible" <?php if($code_posti_varible=='varible'){ echo 'selected'; } ?>>متغییر</option>
                <option value="fix" <?php if($code_posti_varible=='fix'){ echo 'selected'; } ?>>ثابت</option>
              </select>
			  
			  <input type="text" name="code_posti_fix_name" style="width: 199px;" id="code_posti_fix_name" value="<?php echo get_option('code_posti_fix_name'); ?>">
            </label><br/><br/>
			
			<label for="email_user">ایمیل              
              <br/>
              <?php 
              $email_user = get_option('email_user');
              ?>
              <select  class="mobile_call" name="email_user" id="email_user" style="width: 199px;">
                <option value="varible" <?php if($email_user=='varible'){ echo 'selected'; } ?>>متغییر</option>
                <option value="fix" <?php if($email_user=='fix'){ echo 'selected'; } ?>>ثابت</option>
              </select>
              
              <input type="text" name="email_fix_name" style="width: 199px;" id="email_fix_name" value="<?php echo get_option('email_fix_name'); ?>">
            </label><br/><br/>
			
			<label for="address_user">آدرس              
              <br/>
              <?php 
              $address_user = get_option('address_user');
              ?>
              <select  class="mobile_call" name="address_user" id="address_user" style="width: 199px;">
                <option value="varible" <?php if($address_user=='varible'){ echo 'selected'; } ?>>متغییر</option>
                <option value="fix" <?php if($address_user=='fix'){ echo 'selected'; } ?>>ثابت</option>
              </select>
              
              <input type="text" name="address_fix_name" style="width: 199px;" id="address_fix_name" value="<?php echo get_option('address_fix_name'); ?>">
            </label><br/><br/>
	      </p>
	   </li>
	   <li data-title="درگاه پرداخت">
	      <p>
		    <label for="Banking_gateway">درگاه بانکی              
              <br/>
              <?php 
              $Banking_gateway = get_option('Banking_gateway');
              ?>
              <select  class="mobile_call" name="Banking_gateway" id="Banking_gateway" style="width: 199px;">
                <option value="idpay" <?php if($Banking_gateway=='idpay'){ echo 'selected'; } ?>>آیدی پی</option>
              </select>			  
            </label><br/><br/>
			
			<label for="api_key_gateway">Api Key
              <br/><input  class="mobile_call" type="text" style="width: 199px;" name="api_key_gateway" value="<?php echo get_option('api_key_gateway'); ?>">
            </label><br/><br/>
			
			<label for="sandbox_gateway">سندباکس
              <input type="checkbox" name="sandbox_gateway" <?php if(get_option('sandbox_gateway')=='on'){ echo 'checked="checked" value="Yes"';} ?>/>
              <p>اگر این را فعال کنید درگاه در حالت تست (سندباکس) قرار می گیرد</p>
			</label><br/><br/>
	      </p>
	   </li>
	   <li data-title="تنظیمات بسته ها">
	      <p>
	        <label for="show_text_pakage"></label>
            <input style="width: 109px;" type="text" id= "show_text_pakage" name="show_text_pakage" value="<?php echo get_option('show_text_pakage'); ?>" placeholder="">
		    <br/>
		    <br/>
		    <?php
			$package_list_sms_  = $wpdb->get_results("SELECT * FROM {$table_prefix}package_list_sms");
            $count = 1;
			foreach($package_list_sms_ as $p){ ?>
		      <label for="Package_id_<?php echo $count;?>"></label>
			  <input style="width: 109px;" type="text" id= "Package_id_<?php echo $count;?>" name="Package_id_<?php echo $count;?>" value="<?php echo $p->Package_id; ?>" placeholder="آیدی بسته">
			  
			  <label for="Package_name_<?php echo $count;?>"></label>
			  <input style="width: 180px;" type="text" id= "Package_name_<?php echo $count;?>" name="Package_name_<?php echo $count;?>" value="<?php echo $p->Package_name; ?>" placeholder="نمایش اطلاعات">
			  
			  <label for="Package_price_<?php echo $count;?>"></label>
			  <input style="width: 109px;" type="text" id= "Package_price_<?php echo $count;?>" name="Package_price_<?php echo $count;?>" value="<?php echo $p->Package_price; ?>"placeholder="قیمت (ریال)">
  			  
			  <label for="Package_status_<?php echo $count;?>"></label>
			  <select style="width: 109px;" name="Package_status_<?php echo $count;?>" id="Package_status_<?php echo $count;?>" style="width: 193px;">
                <option value="0" <?php if($p->Package_status=='0'){ echo 'selected'; } ?>>فعال</option>
                <option value="1" <?php if($p->Package_status=='1'){ echo 'selected'; } ?>>غیر فعال</option>
              </select>
			  
			  <input type="button" data-id="<?php echo $p->id; ?>" class="button button-danger remove_record" value="-" style="background-color: red;color: white;"/>
			  <br/>
		    <?php $count ++; } ?>
			<div id="wp_panel"></div>
            <input type="button" style="margin-top: 10px;" class="button button-primary" id="add_record" value="add"/>
			<input type="hidden" id="count_record" name="count_record" value="<?php echo $count; ?>"/>
	      </p>
	   </li>
	  </ul>
	  <div style="text-align: left;">
	    <input class="button" name="submit" type="submit" value="ذخیره" style="width: 169px;margin-top: -13px;background-color: #8ae87c;height: 38px;font-weight: bold;margin-left: 28px;">
	  </div>	
    </form>
	<script src="<?php echo register_panel_CSS_URL ?>/vanilla-tabs.min.js"></script>
	<script>
	    jQuery(document).ready(function($){
	      var company = $('#company_varible_name').val(); 
	      if(company == 'varible'){
	        $('#company_fix_name').attr('required', false); 
	        $('#company_fix_name').attr('disabled', 'disabled');
	      }else if(company == 'fix'){
	        $('#company_fix_name').attr('required', true);  
	        $('#company_fix_name').removeAttr('disabled');
	      }
	      
	      var codemeli = $('#codemeli_varible').val(); 
	      if(codemeli == 'varible'){
	        $('#codemeli_fix_name').attr('required', false); 
	        $('#codemeli_fix_name').attr('disabled', 'disabled');
	      }else if(codemeli == 'fix'){
	        $('#codemeli_fix_name').attr('required', true);  
	        $('#codemeli_fix_name').removeAttr('disabled');
	      }
	      
	      var address = $('#address_user').val(); 
	      if(address == 'varible'){
	        $('#address_fix_name').attr('required', false); 
	        $('#address_fix_name').attr('disabled', 'disabled');
	      }else if(address == 'fix'){
	        $('#address_fix_name').attr('required', true);  
	        $('#address_fix_name').removeAttr('disabled');
	      }
	      
	      var shenasnameh = $('#shenasnameh_varible').val(); 
	      if(shenasnameh == 'varible'){
	        $('#shenasnameh_fix_name').attr('required', false); 
	        $('#shenasnameh_fix_name').attr('disabled', 'disabled');
	      }else if(shenasnameh == 'fix'){
	        alert(shenasnameh);
	        $('#shenasnameh_fix_name').attr('required', true);  
	        $('#shenasnameh_fix_name').removeAttr('disabled');
	        
	        $('#codemeli_fix_name').attr('required', true);  
	        $('#codemeli_fix_name').removeAttr('disabled');
	      }
	      
	      var cell_phone = $('#cell_phone_varible').val(); 
	      if(cell_phone == 'varible'){
	        $('#cell_phone_fix_name').attr('required', false); 
	        $('#cell_phone_fix_name').attr('disabled', 'disabled');
	      }else if(cell_phone == 'fix'){
	        $('#cell_phone_fix_name').attr('required', true);  
	        $('#cell_phone_fix_name').removeAttr('disabled');
	      }
	      
	      var code_posti = $('#code_posti_varible').val(); 
	      if(code_posti == 'varible'){
	        $('#code_posti_fix_name').attr('required', false); 
	        $('#code_posti_fix_name').attr('disabled', 'disabled');
	      }else if(code_posti == 'fix'){
	        $('#code_posti_fix_name').attr('required', true);  
	        $('#code_posti_fix_name').removeAttr('disabled');
	      }
	      
	      var phone = $('#phone_varible').val(); 
	      if(phone == 'varible'){
	        $('#phone_fix_name').attr('required', false); 
	        $('#phone_fix_name').attr('disabled', 'disabled');
	      }else if(phone == 'fix'){
	        $('#phone_fix_name').attr('required', true);  
	        $('#phone_fix_name').removeAttr('disabled');
	      }
	      
	      var email_user = $('#email_user').val(); 
	      if(email_user == 'varible'){
	        $('#email_fix_name').attr('required', false); 
	        $('#email_fix_name').attr('disabled', 'disabled');
	      }else if(email_user == 'fix'){
	        $('#email_fix_name').attr('required', true);  
	        $('#email_fix_name').removeAttr('disabled');
	      }
	      
	      $('#company_varible_name').on('change',function(){
	        var company = $(this).val(); 
	        if(company == 'varible'){
	          $('#company_fix_name').attr('required', false); 
	          $('#company_fix_name').attr('disabled', 'disabled');
	        }else if(company == 'fix'){
	          $('#company_fix_name').attr('required', true);  
	          $('#company_fix_name').removeAttr('disabled');
	        }
	      });
	      
	      $('#codemeli_varible').on('change',function(){
	        var codemeli = $(this).val(); 
	        if(codemeli == 'varible'){
	          $('#codemeli_fix_name').attr('required', false); 
	          $('#codemeli_fix_name').attr('disabled', 'disabled');
	        }else if(codemeli == 'fix'){
	          $('#codemeli_fix_name').attr('required', true);  
	          $('#codemeli_fix_name').removeAttr('disabled');
	        }
	      });
	        
	      $('#shenasnameh_varible').on('change',function(){
	        var shenasnameh = $(this).val(); 
	        if(shenasnameh == 'varible'){
	          $('#shenasnameh_fix_name').attr('required', false); 
	          $('#shenasnameh_fix_name').attr('disabled', 'disabled');
	        }else if(shenasnameh == 'fix'){
	          $('#shenasnameh_fix_name').attr('required', true);  
	          $('#shenasnameh_fix_name').removeAttr('disabled');
	          var codemeli_fix_name = $('#codemeli_fix_name').val();
	          $('#shenasnameh_fix_name').val(codemeli_fix_name);
	          
	          $('#codemeli_fix_name').attr('required', true);  
	          $('#codemeli_fix_name').removeAttr('disabled');
	        }
	      });
	        
	      $('#cell_phone_varible').on('change',function(){
	        var cell_phone = $(this).val(); 
	        if(cell_phone == 'varible'){
	          $('#cell_phone_fix_name').attr('required', false); 
	          $('#cell_phone_fix_name').attr('disabled', 'disabled');
	        }else if(cell_phone == 'fix'){
	          $('#cell_phone_fix_name').attr('required', true);  
	          $('#cell_phone_fix_name').removeAttr('disabled');
	        }
	      });
	        
	      $('#phone_varible').on('change',function(){
	        var phone = $(this).val(); 
	        if(phone == 'varible'){
	          $('#phone_fix_name').attr('required', false); 
	          $('#phone_fix_name').attr('disabled', 'disabled');
	        }else if(phone == 'fix'){
	          $('#phone_fix_name').attr('required', true);  
	          $('#phone_fix_name').removeAttr('disabled');
	        }
	      });
	      
	      
	      
	      $('#code_posti_varible').on('change',function(){
	        var code_posti = $(this).val(); 
	        if(code_posti == 'varible'){
	          $('#code_posti_fix_name').attr('required', false); 
	          $('#code_posti_fix_name').attr('disabled', 'disabled');
	        }else if(code_posti == 'fix'){
	          $('#code_posti_fix_name').attr('required', true);  
	          $('#code_posti_fix_name').removeAttr('disabled');
	        }
	      });
	        
	      $('#email_user').on('change',function(){
	        var email_user = $(this).val(); 
	        if(email_user == 'varible'){
	          $('#email_fix_name').attr('required', false); 
	          $('#email_fix_name').attr('disabled', 'disabled');
	        }else if(email_user == 'fix'){
	          $('#email_fix_name').attr('required', true);  
	          $('#email_fix_name').removeAttr('disabled');
	        }
	      });
	      
	      
	        
	      $('#address_user').on('change',function(){
	        var address = $(this).val(); 
	        if(address == 'varible'){
	          $('#address_fix_name').attr('required', false); 
	          $('#address_fix_name').attr('disabled', 'disabled');
	        }else if(address == 'fix'){
	          $('#address_fix_name').attr('required', true);  
	          $('#address_fix_name').removeAttr('disabled');
	        }
	      });
	    });
		document.addEventListener('DOMContentLoaded', () => {

			// create horizontal tabs
			new VanillaTabs({
				'selector': '#tabs-h',	// default is ".tabs"
				'type': 'horizontal', 	// can be horizontal / vertical / accordion
				'responsiveBreak': 840,	// tabs become accordion on this device width
				'activeIndex' : 0				// active tab index (starts from 0 ). Can be -1 for accordions.
			});

			// create vertical tabs
			new VanillaTabs({
				'selector': '#tabs-v',	// default is ".tabs"
				'type': 'vertical', 		// can be horizontal / vertical / accordion
				'responsiveBreak': 840,	// tabs become accordion on this device width
				'activeIndex' : 1				// active tab index (starts from 0 ). Can be -1 for accordions.
			});

			// createaccordion
			new VanillaTabs({
				'selector': '#tabs-a',	// default is ".tabs"
				'type': 'accordion', 		// can be horizontal / vertical / accordion
				'responsiveBreak': 840,	// tabs become accordion on this device width
				'activeIndex' : -1			// active tab index (starts from 0 ). Can be -1 for accordions.
			});

		});
	</script>		
	<?php
}