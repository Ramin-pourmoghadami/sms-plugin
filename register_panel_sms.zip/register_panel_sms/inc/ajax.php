<?php
add_action('wp_ajax_create_element_submit','create_element_submit');
add_action('wp_ajax_nopriv_create_element_submit','create_element_submit');

function create_element_submit(){
	global $wpdb, $table_prefix;
	$count   = intval($_POST['count_record']);
	?>
	<p id="contect_<?php echo $count; ?>">
	<label for="Package_id_<?php echo $count;?>"></label>
	<input style="width: 109px;" type="text" id= "Package_id_<?php echo $count;?>" name="Package_id_<?php echo $count;?>" value="<?php echo $p->Package_id; ?>" placeholder="آیدی بسته">
		
	<label for="Package_name_<?php echo $count;?>"></label>
	<input style="width: 180px;" type="text" id= "Package_name_<?php echo $count;?>" name="Package_name_<?php echo $count;?>" value="<?php echo $p->Package_name; ?>" placeholder="نمایش اطلاعات">
			  
	<label for="Package_price_<?php echo $count;?>"></label>
	<input style="width: 109px;" type="text" id= "Package_price_<?php echo $count;?>" name="Package_price_<?php echo $count;?>" value="<?php echo $p->Package_price; ?>" placeholder="قیمت (ریال)">
  			  
	<label for="Package_status_<?php echo $count;?>"></label>
	<select style="width: 109px;" name="Package_status_<?php echo $count;?>" id="Package_status_<?php echo $count;?>" style="width: 193px;">
      <option value="0">فعال</option>
      <option value="1">غیر فعال</option>
    </select>
    
	<input type="button" data-id="<?php echo $count; ?>" class="button button-danger remove_row" value="-" style="background-color: red;color: white;"/>
	</p>
	<?php
	die();
}