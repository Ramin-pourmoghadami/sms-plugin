jQuery(document).ready(function($){      
    $('#add_record').on('click',function(){
      var count_record = $('#count_record').val();
	  if(count_record ==0){
		count_record =1;
	  }
	  var panel=$('#wp_panel');
      $.ajax({
        url:wpagahi.ajaxurl,
        type:'post',
        data:{
          action:'create_element_submit',
		  count_record:count_record,
        },
        success:function(res){
          panel.append(res).slideDown(300);
		  count_record = parseInt(count_record)+1;
		  $('#count_record').val(count_record);	
		  $('.remove_row').on('click',function(){
		    if(!confirm("برای حذف کردن این رکورد اطمینان دارید؟")){return false;}
	        var pid=$(this).data('id');
	        $("#contect_"+pid).remove();
	        alert('رکورد مورد نظر حذف شد');
		  });
        },
        error:function(){}
      });
      return false;
    });	
}); 
