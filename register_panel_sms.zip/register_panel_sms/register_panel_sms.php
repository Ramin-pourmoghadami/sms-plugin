<?php
/**
  *Plugin Name: پلاگین ثبت نام پیامکی
  *Plugin URI:#
  *Description: پلاگین ثبت نام پیامکی
  *Version: 1.0
  *Author:یک پیامک
  *Author URI:https://www.rtl-theme.com/author/yekpayamak/
  *License:GPL v2
*/

ob_start();
defined( 'ABSPATH' ) || exit;
define( 'register_panel_DIR', plugin_dir_path( __FILE__ ) );
define( 'register_panel_INC_DIR', trailingslashit( register_panel_DIR . 'inc' ) );
define( 'register_panel_URL', plugin_dir_url( __FILE__ ) );
define( 'register_panel_CSS_URL', trailingslashit( register_panel_URL . 'css' ) );
define( 'register_panel_JS_URL', trailingslashit( register_panel_URL . 'js' ) );
define( 'register_panel_IMG_URL', trailingslashit( register_panel_URL . 'img' ) );
define( 'register_panel_Product_URL', trailingslashit( register_panel_URL . 'product_imge' ) );

include_once register_panel_INC_DIR.'shortcodes.php';
if(is_admin()){
   include_once register_panel_INC_DIR.'backend.php'; 
   include_once register_panel_INC_DIR.'ajax.php';
   include_once register_panel_INC_DIR.'pages.php';
   
   add_action('admin_menu','register_panel_add_menus');
}

register_activation_hook(__FILE__,'register_panel_activate');
register_deactivation_hook(__FILE__,'register_panel_deactivate');

function register_panel_activate(){
    global $table_prefix;
	/* statuse= 0 = در انتظار پرداخت*/
	$create_user_sms_order_sql='CREATE TABLE IF NOT EXISTS `'.$table_prefix.'create_user_sms_order` (
	   `id` bigint(10) NOT NULL AUTO_INCREMENT,
	   `user_id` varchar(30) COLLATE utf8_persian_ci NOT NULL,
	   `user_name` varchar(30) COLLATE utf8_persian_ci NOT NULL,
	   `User_pass` varchar(30) COLLATE utf8_persian_ci NOT NULL,
	   `name` varchar(30) COLLATE utf8_persian_ci NOT NULL,
	   `company` varchar(30) COLLATE utf8_persian_ci NOT NULL,
	   `national_id` varchar(30) COLLATE utf8_persian_ci NOT NULL,
	   `certificate_id` varchar(30) COLLATE utf8_persian_ci NOT NULL,
	   `access_id` varchar(30) COLLATE utf8_persian_ci NOT NULL,
	   `Tell` varchar(30) COLLATE utf8_persian_ci NOT NULL,
	   `mobile` varchar(30) COLLATE utf8_persian_ci NOT NULL,
	   `postalcode` varchar(30) COLLATE utf8_persian_ci NOT NULL,
	   `email` varchar(30) COLLATE utf8_persian_ci NOT NULL,
	   `address` varchar(30) COLLATE utf8_persian_ci NOT NULL,
	   `statuse` varchar(30) COLLATE utf8_persian_ci NOT NULL,
	   `create_at` varchar(10) COLLATE utf8_persian_ci NOT NULL,
       PRIMARY KEY (`id`)
      ) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=1';
	  
    $package_list_sql='CREATE TABLE IF NOT EXISTS `'.$table_prefix.'package_list_sms` (
	   `id` bigint(10) NOT NULL AUTO_INCREMENT,
	   `Package_id` varchar(10) COLLATE utf8_persian_ci NOT NULL,
	   `Package_name` varchar(30) COLLATE utf8_persian_ci NOT NULL,
	   `Package_price` varchar(10) COLLATE utf8_persian_ci NOT NULL,
	   `Package_status` varchar(10) COLLATE utf8_persian_ci NOT NULL,
       PRIMARY KEY (`id`)
      ) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=1';
    
   require_once ABSPATH.'/wp-admin/includes/upgrade.php';
   dbDelta($create_user_sms_order_sql);
   dbDelta($package_list_sql);
}
function register_panel_deactivate(){}

function register_panel_send_sms($cell_phone,$pattern_code,$phone){
	$username     = get_option('user_rps');
    $password     = get_option('user_pass_rps');
    $from         = get_option('num_rps');
    $pattern_code = $pattern_code;
    $to           = array($cell_phone);
	$input_data = array(
	  "user" => $phone
	);
    
    $url = "https://ippanel.com/patterns/pattern?username=" . $username . "&password=" . urlencode($password) . "&from=$from&to=" . json_encode($to) . "&input_data=" . urlencode(json_encode($input_data)) . "&pattern_code=$pattern_code";
    $handler = curl_init($url);
    curl_setopt($handler, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($handler, CURLOPT_POSTFIELDS, $input_data);
    curl_setopt($handler, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($handler);
}

function register_panel_send_sms_success($cell_phone,$pattern_code,$phone,$name,$pass){
	$username     = get_option('user_rps');
    $password     = get_option('user_pass_rps');
    $from         = get_option('num_rps');
    $pattern_code = $pattern_code;
    $to           = array($cell_phone);
	$input_data = array(
	  "user" => $phone,
	  "name" => $name,
	  "pass" => $pass
	);
    
    $url = "https://ippanel.com/patterns/pattern?username=" . $username . "&password=" . urlencode($password) . "&from=$from&to=" . json_encode($to) . "&input_data=" . urlencode(json_encode($input_data)) . "&pattern_code=$pattern_code";
    $handler = curl_init($url);
    curl_setopt($handler, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($handler, CURLOPT_POSTFIELDS, $input_data);
    curl_setopt($handler, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($handler);
}

function register_panel_send_voice($cell_phone){
    $username     = get_option('user_rps');
    $password     = get_option('user_pass_rps');
    $voice_       = get_option('voice_tanks_user');
	
	$url = "https://ippanel.com/services.jspd";
		
	$rcpt_nm = array($cell_phone);
	$param = array
	(
		'uname'=> $username,
		'pass'=> $password,
		'repeat'=>'1', 
		'to'=>json_encode($rcpt_nm),
		'fileUrl'=> $voice_,		//wav
		'op'=>'sendvoice'
	);
				
	$handler = curl_init($url);             
	curl_setopt($handler, CURLOPT_CUSTOMREQUEST, "POST");
	curl_setopt($handler, CURLOPT_POSTFIELDS, $param);                       
	curl_setopt($handler, CURLOPT_RETURNTRANSFER, true);
	$response2 = curl_exec($handler);

	$response2 = json_decode($response2);
	$res_code = $response2[0];
	$res_data = $response2[1];
}

function register_panel_session_start() {
    if(!session_id()) {
      session_start();
    }
}
function register_panel_session_end() {
    if(session_id())
    {
        $_SESSION=array();
        session_destroy ();
    }
}