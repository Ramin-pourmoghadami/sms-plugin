<?php
add_shortcode("create_user_sms","rps_create_user_form");

function rps_create_user_form(){
	global $wpdb, $table_prefix, $current_user;
    
	$cell_mobile_admin    = get_option('cell_mobile_admin');
    $pattern_user_success = get_option('pattern_user_success');
	$pattern_user_failed = get_option('pattern_user_failed');
	  
	$pattern_admin_success = get_option('pattern_admin_success');
	$pattern_admin_failed = get_option('pattern_admin_failed');
	  
	$Success_user_page = get_option('Success_user_page');
	$User_failed_page = get_option('User_failed_page');
	  
	$voice_tanks_user = get_option('voice_tanks_user');
	$api_key_gateway  = get_option('api_key_gateway');
	
	$sandbox_gateway  = get_option('sandbox_gateway');
	$SANDBOX = 0;
	if($sandbox_gateway == 'on'){
	   $SANDBOX = 1; 
	}
	
	$method = $_SERVER['REQUEST_METHOD'];
    if ($method == 'POST') {
      $status = sanitize_text_field($_POST['status']);
      $track_id = sanitize_text_field($_POST['track_id']);//کد رهگیری
      $id = sanitize_text_field($_POST['id']);
      $order_id = sanitize_text_field($_POST['order_id']);
      $amount   = sanitize_text_field($_POST['amount']);
    }elseif ($method == 'GET') {
      $status = sanitize_text_field($_GET['status']);
      $track_id = sanitize_text_field($_GET['track_id']);
      $id = sanitize_text_field($_GET['id']);
      $order_id = sanitize_text_field($_GET['order_id']);
    }
    
	if ($status == 10 || $status == 100) {
	  $params = array(
        'id' => $id,
        'order_id' => $order_id,
      );

      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, 'https://api.idpay.ir/v1.1/payment/verify');
      curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
      curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'X-API-KEY: '.$api_key_gateway,
        'X-SANDBOX: '.$SANDBOX,
      ));

      $result = curl_exec($ch);
      curl_close($ch);
      $result = json_decode($result);
    
      $status = $result->status;
      $id = $result->id;
      $order_id = $result->order_id;
	  /* start create user panel sms */
	  if($status == 100){
	    $create_user_sms_order  = $wpdb->get_row("SELECT * FROM {$table_prefix}create_user_sms_order where id='{$order_id}'");
	    if(count($create_user_sms_order)){
	   	   $name = $create_user_sms_order->name;
	       $company = $create_user_sms_order->company;
	       $national_id = $create_user_sms_order->national_id;
	       $certificate_id = $create_user_sms_order->certificate_id;
	       $access_id = $create_user_sms_order->access_id;
	       $Tell = $create_user_sms_order->Tell;
	       $mobile = $create_user_sms_order->mobile;
	       $postalcode = $create_user_sms_order->postalcode;
	       $email = $create_user_sms_order->email;
	       $address = $create_user_sms_order->address; 
	       
	       $url = 'https://ippanel.com/services.jspd';
	  
	       $first_user_name     = get_option('first_user_name');
	       $user_name_code_meli = get_option('user_name_code_meli');
	       if($user_name_code_meli == 'code_meli'){
		     $User_name = $first_user_name . $national_id;  
	       }else if($user_name_code_meli == 'cell_phone'){
		     $User_name = $first_user_name . $mobile;  
	       }
	  
	       $first_password     = get_option('first_password');
	       $password_code_meli = get_option('password_code_meli');
	       if($password_code_meli == 'code_meli'){
		     $User_pass = $first_password . $national_id;  
	       }else if($password_code_meli == 'cell_phone'){
	    	 $User_pass = $first_password . $mobile;  
	       }
	       
	       $param = array ( 
		     'uname'=> get_option('user_rps'),
             'pass'=> get_option('user_pass_rps'),
             'user_uname'=>$User_name,
             'user_pass'=>$User_pass,
             'name'=>$name,
             'company'=>$company,
             'national_id'=>$national_id,
             'certificate_id'=>$certificate_id,
             'access_id'=>$access_id,
             'tell'=>$Tell,
             'mobile'=>$mobile,
             'postalcode'=>$postalcode,
             'email'=>$email,
             'address'=>$address,
             'op'=>'newuser'
           );

           $handler = curl_init($url);
           curl_setopt($handler, CURLOPT_CUSTOMREQUEST, 'POST');
           curl_setopt($handler, CURLOPT_POSTFIELDS, $param);
           curl_setopt($handler, CURLOPT_RETURNTRANSFER, true);
           $response2 = curl_exec($handler);

           $response2 = json_decode($response2);
           $res_code = $response2[0];
           $res_data = $response2[1]; 
           
	       if($res_code == '0'){
	         //echo $res_data;
		     register_panel_send_sms_success($mobile,$pattern_user_success,$User_name,$name,$User_pass);
		     register_panel_send_sms($cell_mobile_admin,$pattern_admin_success,$User_name);
     		 register_panel_send_voice($mobile);
		     wp_redirect($Success_user_page);
	       }else{
	         //echo $res_data;
		     register_panel_send_sms($mobile,$pattern_user_failed,$User_name);
		     register_panel_send_sms($cell_mobile_admin,$pattern_admin_failed,$User_name);
             wp_redirect($User_failed_page);		
	       }
	       /* end create user panel sms */  
	     }
	  }
	}else if($status == 1 || $status == 2 || $status == 3 || $status == 4 || $status == 5 || $status == 6 || $status == 7 || $status == 8 || $status == 101){
	    $first_user_name     = get_option('first_user_name');
	    $user_name_code_meli = get_option('user_name_code_meli');
	    if($user_name_code_meli == 'code_meli'){
		  $User_name = $first_user_name . $national_id;  
	    }else if($user_name_code_meli == 'cell_phone'){
		  $User_name = $first_user_name . $mobile;  
	    }
		register_panel_send_sms($mobile,$pattern_user_failed,$User_name);
		register_panel_send_sms($cell_mobile_admin,$pattern_admin_failed,$User_name);
        wp_redirect($User_failed_page);
	}
    /* end create payment idpay */	
    $callback .= $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"];
    $company_varible_name = get_option('company_varible_name');
    $codemeli_varible = get_option('codemeli_varible');
    $shenasnameh_varible = get_option('shenasnameh_varible');
    $cell_phone_varible = get_option('cell_phone_varible');
    $phone_varible = get_option('phone_varible');
    $code_posti_varible = get_option('code_posti_varible');
    $email_user = get_option('email_user');
    $address_user = get_option('address_user');
    ?>
	<p><input type="text" name="name" id="name" style="width: 100%;" placeholder="نام و نام خانوادگی"/></p>
	<?php if($company_varible_name == 'varible'){ ?>
	<p><input type="text" name="company" style="width: 100%;" id="company" placeholder="شرکت"/></p>
	<?php } ?>
	<?php if($codemeli_varible == 'varible'){ ?>
	<p><input type="text" name="national_id" style="width: 100%;" id="national_id" placeholder="کد ملی"/></p>
	<?php } ?>
	<?php if($shenasnameh_varible == 'varible'){ ?>
	<p><input type="text" name="certificate_id" style="width: 100%;" id="certificate_id" placeholder="شماره شناسنامه"/></p>
	<?php } ?>
	<?php if($phone_varible == 'varible'){ ?>
	<p><input type="text" name="Tell" id="Tell" style="width: 100%;" placeholder="تلفن"/></p>
	<?php } ?>
	<?php if($cell_phone_varible == 'varible'){ ?>
	<p><input type="text" name="mobile" id="mobile" style="width: 100%;" placeholder="موبایل"/></p>
	<?php } ?>
	<?php if($code_posti_varible == 'varible'){ ?>
	<p><input type="text" name="postalcode" style="width: 100%;" id="postalcode" placeholder="کد پستی"/></p>
	<?php } ?>
	<?php if($email_user == 'varible'){ ?>
	<p><input type="text" name="email" id="email" style="width: 100%;" placeholder="ایمیل"/></p>
	<?php } ?>
	<?php if($address_user == 'varible'){ ?>
	<p><input type="text" name="address" id="address" style="width: 100%;" placeholder="آدرس"/></p>
	<?php } ?>
	<p>
	<?php 
	$package_list_sms_  = $wpdb->get_results("SELECT * FROM {$table_prefix}package_list_sms");
	?>
	<p>
	<?php echo get_option('show_text_pakage'); ?><br/>
    <select name="select_panel_rps" id="select_panel_rps" style="width: 100%;background-color: white;">
      <option value="-1">انتخاب کنید</option>
      <?php foreach($package_list_sms_ as $p){ ?>
	    <option value="<?php echo $p->Package_id; ?>"><?php echo $p->Package_name .'-'.$p->Package_price; ?></option>
      <?php } ?>
    </select>
    </p>
    <p style="text-align: left;">
	<button type="button" id="register_panel" style="border-radius: 5px;background-color: #38b449;height: 45px;font-weight: bold;color: white;padding-right: 10px;padding-left: 10px;"><?php echo get_option('text_register_user'); ?></button> 
	</p>
	<input type="hidden" name="task" value="register" />

	<script type="text/javascript"> 
	jQuery(document).ready(function($){ 
	  $('#register_panel').on('click',function(){
	    var name = $("#name").val();
	    var company = $("#company").val();  
		var national_id = $("#national_id").val();
				
		var certificate_id = $("#certificate_id").val(); 
		var Tell = $("#Tell").val();
		var mobile = $("#mobile").val();  
		var postalcode = $("#postalcode").val();  
		var email = $("#email").val();  
		var address = $("#address").val();  
		var select_panel_rps = $("#select_panel_rps").val(); 
		  
        $.post('<?php echo admin_url( "admin-ajax.php" );?>', {
          action: 'register_panel_sms',
          name   : name,    
          company   : company,
          national_id   : national_id,
          certificate_id   : certificate_id,
          Tell   : Tell,
          mobile   : mobile,
          postalcode : postalcode,
          email : email,
          address : address,
          select_panel_rps : select_panel_rps,
          callback  : <?php echo json_encode($callback); ?>
        }, function (data) {
          var res = JSON.parse(data);
          if(res.status){
		    window.location.replace(res.url);
		  }else if(res.status == false){
            alert(res.message);
		  }		
        });	               
	  });  
	});
	</script>
	<?php
}

add_action('wp_ajax_register_panel_sms', 'register_panel_sms');
add_action('wp_ajax_nopriv_register_panel_sms','register_panel_sms');

function register_panel_sms(){
  global $wpdb, $table_prefix ,$current_user;
  
  $cell_mobile_admin    = get_option('cell_mobile_admin');
  $pattern_user_success = get_option('pattern_user_success');
  $pattern_user_failed = get_option('pattern_user_failed');
	  
  $pattern_admin_success = get_option('pattern_admin_success');
  $pattern_admin_failed = get_option('pattern_admin_failed');
	  
  $Success_user_page = get_option('Success_user_page');
  $User_failed_page = get_option('User_failed_page');
	  
  $voice_tanks_user = get_option('voice_tanks_user');
  $api_key_gateway  = get_option('api_key_gateway');
  
  $company_varible_name = get_option('company_varible_name');
  $codemeli_varible = get_option('codemeli_varible');
  $shenasnameh_varible = get_option('shenasnameh_varible');
  $cell_phone_varible = get_option('cell_phone_varible');
  $phone_varible = get_option('phone_varible');
  $code_posti_varible = get_option('code_posti_varible');
  $email_user = get_option('email_user');
  $address_user = get_option('address_user');
	
  $name = $_POST['name'];
  if($company_varible_name == 'varible'){
    $company = $_POST['company'];  
  }else if($company_varible_name == 'fix'){
    $company = get_option('company_fix_name');  
  }
  
  if($codemeli_varible == 'varible'){
    $national_id = $_POST['national_id'];  
  }else if($codemeli_varible == 'fix'){
    $national_id = get_option('codemeli_fix_name');  
  }
  
  
  if($shenasnameh_varible == 'varible'){
    $certificate_id = $_POST['certificate_id'];  
  }else if($shenasnameh_varible == 'fix'){
    $certificate_id = get_option('shenasnameh_fix_name');  
  }
  
  if($phone_varible == 'varible'){
    $Tell = $_POST['Tell'];  
  }else if($phone_varible == 'fix'){
    $Tell = get_option('phone_fix_name');  
  }
  
  if($cell_phone_varible == 'varible'){
    $mobile = $_POST['mobile'];  
  }else if($cell_phone_varible == 'fix'){
    $mobile = get_option('cell_phone_fix_name');  
  }
  
  if($code_posti_varible == 'varible'){
    $postalcode = $_POST['postalcode'];  
  }else if($code_posti_varible == 'fix'){
    $postalcode = get_option('code_posti_fix_name');  
  }
  
  if($email_user == 'varible'){
    $email = $_POST['email'];  
  }else if($email_user == 'fix'){
    $email = get_option('email_fix_name');  
  }
  
  if($address_user == 'varible'){
    $address = $_POST['address'];  
  }else if($address_user == 'fix'){
    $address = get_option('address_fix_name');  
  }
  
  $access_id = $_POST['select_panel_rps'];
  $callback  = $_POST['callback'];
  
  $checkMeliCode = checkMeliCode($national_id);
  
  $first_user_name     = get_option('first_user_name');
  $user_name_code_meli = get_option('user_name_code_meli');
  if($user_name_code_meli == 'code_meli'){
    $User_name = $first_user_name . $national_id;  
  }else if($user_name_code_meli == 'cell_phone'){
    $User_name = $first_user_name . $mobile;  
  }

  if($checkMeliCode == false){
    $return_arr['status']  = false;
    $return_arr['message'] = 'کد ملی وارد شده نامعتبر می باشد';
    echo json_encode($return_arr);
    die;
  }

  $user_id    = $current_user->ID;
  
  $package_list_sms  = $wpdb->get_row("SELECT * FROM {$table_prefix}package_list_sms where Package_id='{$access_id}'");
  
  if(count($package_list_sms)){
	$Package_price = $package_list_sms->Package_price;
  }else{
    $return_arr['status']  = false;
    $return_arr['message'] = 'بسته ای تعریف نشده'.$err;
    echo json_encode($return_arr);
    die;  
  }

  if($address == "" && $email == "" && $postalcode == "" && $mobile == "" && $Tell == "" && $national_id == "" && $certificate_id == "" && $name == "" && $company == ""){
      $return_arr['status']  = false;
	  $return_arr['message'] = 'لطفا فیلدهای مورد نظر را پر کید'.$err;
	  echo json_encode($return_arr);
	  die;
  }else{
	$sql="INSERT INTO {$table_prefix}create_user_sms_order (user_id,user_name,User_pass,name,company,national_id,certificate_id,access_id,Tell,mobile,postalcode,email,address,statuse,create_at) ";
	$sql.="VALUES('{$user_id}','','','{$name}','{$company}','{$national_id}','{$certificate_id}','{$access_id}','{$Tell}','{$mobile}','{$postalcode}','{$email}','{$address}','0','{$create_at}')";
	$res=$wpdb->query($sql);
    $order_id = $wpdb->insert_id;
    
    $sandbox_gateway  = get_option('sandbox_gateway');
	$SANDBOX = 0;
	if($sandbox_gateway == 'on'){
	   $SANDBOX = 1; 
	}
	
	$params = array(
      'order_id' => $order_id,
      'amount' => intval($Package_price),
      'name' => $name,
      'phone' => $mobile,
      'mail' => $email,
      'desc' => 'توضیحات پرداخت کننده',
      'callback' => $callback,
    );

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://api.idpay.ir/v1.1/payment');
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
      'Content-Type: application/json',
      'X-API-KEY: '.$api_key_gateway,
      'X-SANDBOX: '.$SANDBOX
    ));

    $result = curl_exec($ch);
    curl_close($ch);
    $result = json_decode($result);
    
    $id = $result->id;
    $link = $result->link;
    $error_code = $result->error_code;
    $error_message = $result->error_message;
    
    if ($error_code) {
      $return_arr['status']  = false;
	  $return_arr['message'] = $error_message;
	  echo json_encode($return_arr);
	  
	  register_panel_send_sms($mobile,$pattern_user_failed,$User_name);
	  register_panel_send_sms($cell_mobile_admin,$pattern_admin_failed,$User_name);
      //wp_redirect($User_failed_page);
	  die;
    } else {
      $return_arr['status']  = true;
	  $return_arr['url']  = $link;	
	  echo json_encode($return_arr);
	  die;
    }
  }
}

function checkMeliCode($meli)
{
  $cDigitLast = substr($meli , strlen($meli)-1);
  $fMeli = strval(intval($meli));
 
  if((str_split($fMeli))[0] == "0" && !(8 <= strlen($fMeli)  && strlen($fMeli) < 10)) return false;
 
  $nineLeftDigits = substr($meli , 0 , strlen($meli) - 1);
   
  $positionNumber = 10;
  $result = 0;
 
  foreach(str_split($nineLeftDigits) as $chr){
        $digit = intval($chr);
        $result += $digit * $positionNumber;
        $positionNumber--;
  }
 
  $remain = $result % 11;
 
  $controllerNumber = $remain;
 
  if(2 < $remain){
    $controllerNumber = 11-$remain;
  }
 
  return $cDigitLast == $controllerNumber;
   
}
