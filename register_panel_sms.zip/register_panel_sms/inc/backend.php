<?php
function register_panel_add_menus(){
	$register_user         =  add_menu_page('پلاگین ثبت نام کاربر','پلاگین ثبت نام کاربر','read','register_user','panel_sms_setting_page');
    $register_user_setting = add_submenu_page('register_user','تنظیمات','تنظیمات','read','register_user');
    
	add_action("load-{$register_user}","load_register_panel_scripts");
	add_action("load-{$register_user_setting}","load_register_panel_scripts");
}
function load_register_panel_scripts(){
	wp_register_style('wp_admin_style',register_panel_CSS_URL.'wp_admin_style.css');
    wp_enqueue_style('wp_admin_style');
	
    wp_register_script('wp_admin_script_',register_panel_JS_URL.'wp_admin_script_.js',array('jquery'));
    wp_localize_script('wp_admin_script_','wpagahi',array('ajaxurl'=>admin_url('admin-ajax.php')));
    wp_enqueue_script('wp_admin_script_');
}